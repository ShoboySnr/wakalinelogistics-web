<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Modules\Admin\Models\RouteShare;
use App\Modules\Admin\Services\OrderService;
use App\Modules\Admin\Services\RouteOptimizationService;
use Illuminate\Http\Request;

class RouteShareApiController extends Controller
{
    public function optimizedRoute(Request $request, $riderId, RouteOptimizationService $optimizer)
    {
        $routeShare = RouteShare::where('rider_id', $riderId)->firstOrFail();

        if (! $routeShare->isValid()) {
            return response()->json(['error' => 'Invalid or expired route link'], 404);
        }

        $coords = $request->validate([
            'lat' => 'nullable|numeric|between:-90,90',
            'lng' => 'nullable|numeric|between:-180,180',
        ]);

        return response()->json([
            'success' => true,
            'data' => $optimizer->optimize($routeShare->rider, $coords['lat'] ?? null, $coords['lng'] ?? null),
        ]);
    }

    public function routeStatus(Request $request, $riderId, $orderId, OrderService $orders)
    {
        $routeShare = RouteShare::where('rider_id', $riderId)->firstOrFail();

        if (! $routeShare->isValid()) {
            return response()->json(['error' => 'Invalid or expired route link'], 404);
        }

        $data = $request->validate([
            'status' => 'required|in:' . implode(',', OrderService::ROUTE_STATUSES),
        ]);

        $order = $routeShare->rider->orders()->findOrFail($orderId);
        $orders->updateStatus($order, $data['status']);

        return response()->json(['success' => true, 'message' => 'Order status updated']);
    }

    public function paymentCollected($riderId, $orderId, OrderService $orders)
    {
        $routeShare = RouteShare::where('rider_id', $riderId)->firstOrFail();

        if (! $routeShare->isValid()) {
            return response()->json(['error' => 'Invalid or expired route link'], 404);
        }

        $order = $routeShare->rider->orders()->findOrFail($orderId);
        $orders->markPaymentCollected($order);

        return response()->json(['success' => true, 'message' => 'Payment marked as collected']);
    }

    public function getRouteData($riderId)
    {
        $routeShare = RouteShare::where('rider_id', $riderId)->firstOrFail();
        
        if (!$routeShare->isValid()) {
            return response()->json(['error' => 'Invalid or expired route link'], 404);
        }
        
        // Increment view count
        $routeShare->incrementViewCount();
        
        // Load rider with pending orders
        $rider = $routeShare->rider;
        $pendingOrders = $rider->orders()
            ->whereIn('status', ['pending', 'confirmed', 'in_transit'])
            ->latest()
            ->get();
        
        // Build route waypoints
        $startingPoint = 'Iju Ishaga, Lagos, Nigeria';
        $waypoints = [];
        $cumulativeTime = 0;
        
        foreach ($pendingOrders as $order) {
            // Add pickup location only if not yet picked up
            if ($order->pickup_address && !$order->pickup_date) {
                $estimatedTravelTime = $order->distance ? ($order->distance * 5) : 15;
                $cumulativeTime += $estimatedTravelTime + 5;
                
                $waypoints[] = [
                    'address' => $order->pickup_address,
                    'type' => 'pickup',
                    'order_number' => $order->order_number,
                    'order_id' => $order->id,
                    'sender' => $order->sender_name ?? $order->customer_name,
                    'phone' => $order->sender_phone ?? $order->customer_phone,
                    'estimated_time' => $cumulativeTime,
                    'eta' => now()->addMinutes($cumulativeTime)->format('g:i A'),
                    'status' => $order->status,
                    'pickup_date' => $order->pickup_date
                ];
            }
            
            // Add delivery location
            if ($order->delivery_address) {
                $estimatedTravelTime = $order->distance ? ($order->distance * 5) : 15;
                $cumulativeTime += $estimatedTravelTime + 5;
                
                $waypoints[] = [
                    'address' => $order->delivery_address,
                    'type' => 'delivery',
                    'order_number' => $order->order_number,
                    'order_id' => $order->id,
                    'receiver' => $order->receiver_name ?? 'N/A',
                    'phone' => $order->receiver_phone ?? 'N/A',
                    'estimated_time' => $cumulativeTime,
                    'eta' => now()->addMinutes($cumulativeTime)->format('g:i A'),
                    'status' => $order->status,
                    'delivery_date' => $order->delivery_date
                ];
            }
        }
        
        return response()->json([
            'success' => true,
            'rider' => [
                'id' => $rider->id,
                'name' => $rider->name,
                'phone' => $rider->phone,
                'vehicle_type' => $rider->vehicle_type,
                'vehicle_number' => $rider->vehicle_number,
                'status' => $rider->status,
                'current_latitude' => $rider->current_latitude ?? null,
                'current_longitude' => $rider->current_longitude ?? null,
                'last_location_update' => $rider->last_location_update ?? null
            ],
            'waypoints' => $waypoints,
            'starting_point' => $startingPoint,
            'total_stops' => count($waypoints),
            'total_estimated_time' => $cumulativeTime,
            'last_updated' => now()->toIso8601String()
        ]);
    }
    
    public function getGroupedOrdersHtml($riderId)
    {
        $routeShare = RouteShare::where('rider_id', $riderId)->firstOrFail();
        
        if (!$routeShare->isValid()) {
            return response()->json(['error' => 'Invalid or expired route link'], 404);
        }
        
        $rider = $routeShare->rider;
        $controller = app(\App\Http\Controllers\RouteShareController::class);
        $data = $controller->prepareRouteData($rider);
        
        $html = view('partials.grouped-orders', $data)->render();
        
        return response()->json([
            'success' => true,
            'html' => $html,
            'order_count' => count($data['waypoints'])
        ]);
    }
    
    public function updateRiderLocation(Request $request, $riderId)
    {
        $routeShare = RouteShare::where('rider_id', $riderId)->firstOrFail();
        
        if (!$routeShare->isValid()) {
            return response()->json(['error' => 'Invalid or expired route link'], 404);
        }
        
        $validated = $request->validate([
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180'
        ]);
        
        $rider = $routeShare->rider;
        $rider->update([
            'current_latitude' => $validated['latitude'],
            'current_longitude' => $validated['longitude'],
            'last_location_update' => now()
        ]);
        
        return response()->json([
            'success' => true,
            'message' => 'Location updated successfully',
            'latitude' => $rider->current_latitude,
            'longitude' => $rider->current_longitude,
            'updated_at' => $rider->last_location_update
        ]);
    }
    
    public function updateOrderStatus(Request $request, $riderId, $orderId)
    {
        $routeShare = RouteShare::where('rider_id', $riderId)->firstOrFail();
        
        if (!$routeShare->isValid()) {
            return response()->json(['error' => 'Invalid or expired route link'], 404);
        }
        
        $validated = $request->validate([
            'status' => 'required|in:pending,confirmed,in_transit,delivered,cancelled',
            'pickup_date' => 'nullable|date',
            'delivery_date' => 'nullable|date',
            'notes' => 'nullable|string',
            'order_ids' => 'nullable|array'
        ]);
        
        $rider = $routeShare->rider;
        
        // Check if multiple order IDs are provided (for grouped pickups)
        if (isset($validated['order_ids']) && is_array($validated['order_ids'])) {
            $orderIds = $validated['order_ids'];
            $orders = $rider->orders()->whereIn('id', $orderIds)->get();
            
            if ($orders->isEmpty()) {
                return response()->json(['error' => 'No valid orders found'], 404);
            }
            
            // Update all orders in the group
            foreach ($orders as $order) {
                $order->update([
                    'status' => $validated['status'],
                    'pickup_date' => $validated['pickup_date'] ?? $order->pickup_date,
                    'delivery_date' => $validated['delivery_date'] ?? $order->delivery_date,
                    'notes' => $validated['notes'] ?? $order->notes
                ]);
            }
            
            return response()->json([
                'success' => true,
                'message' => count($orders) . ' orders updated successfully',
                'orders_updated' => $orders->pluck('id')->toArray()
            ]);
        }
        
        // Single order update (backward compatibility)
        $order = $rider->orders()->findOrFail($orderId);
        
        $order->update($validated);
        
        return response()->json([
            'success' => true,
            'message' => 'Order status updated successfully',
            'order' => [
                'id' => $order->id,
                'order_number' => $order->order_number,
                'status' => $order->status,
                'pickup_date' => $order->pickup_date,
                'delivery_date' => $order->delivery_date
            ]
        ]);
    }

    public function validateDailyCode(Request $request, $riderId)
    {
        $routeShare = RouteShare::where('rider_id', $riderId)->firstOrFail();
        
        if (!$routeShare->isValid()) {
            return response()->json(['error' => 'Invalid or expired route link'], 404);
        }
        
        $request->validate([
            'code' => 'required|string|size:6'
        ]);
        
        $rider = $routeShare->rider;
        $isValid = $rider->validateDailyCode($request->code);
        
        if ($isValid) {
            return response()->json([
                'success' => true,
                'message' => 'Code validated successfully',
                'rider_name' => $rider->name
            ]);
        }
        
        return response()->json([
            'success' => false,
            'message' => 'Invalid code. Please check and try again.'
        ], 401);
    }
}
