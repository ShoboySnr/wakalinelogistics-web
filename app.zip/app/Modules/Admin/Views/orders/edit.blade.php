@extends('Admin::layout')

@section('title', 'Edit Order')

@section('content')
<div class="px-4 sm:px-6 lg:px-0">
    <div class="mb-6">
        <a href="{{ route('admin.orders.show', $order->id) }}" class="brand-accent-text text-sm font-medium" style="transition: color 0.2s ease;" onmouseover="this.style.color='#a8555a';" onmouseout="this.style.color='#C1666B';">
            ← Back to Order Details
        </a>
    </div>

    <div class="bg-white shadow rounded-lg overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
            <h2 class="text-xl font-semibold text-gray-900">Edit Order #{{ $order->order_number }}</h2>
        </div>
        
        <form action="{{ route('admin.orders.update', $order->id) }}" method="POST" enctype="multipart/form-data" class="px-6 py-6">
            @csrf
            @method('PUT')

            @if ($errors->any())
                <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-r-lg">
                    <div class="flex items-start">
                        <svg class="h-5 w-5 text-red-500 mt-0.5 mr-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
                        </svg>
                        <div class="flex-1">
                            <ul class="list-disc list-inside text-sm text-red-700">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                </div>
            @endif

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Client Selection (Optional) -->
                <div class="md:col-span-2 bg-pink-50 border-2 rounded-lg p-4 mb-4" style="border-color: #C1666B;">
                    <h3 class="text-sm font-semibold mb-3 flex items-center brand-accent-text">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                        </svg>
                        Quick Fill from Existing Client
                    </h3>
                    <div>
                        <label for="client_id" class="block text-sm font-medium text-gray-700 mb-2">
                            Select Client (Optional)
                        </label>
                        <select name="client_id" id="client_id"
                                class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 bg-white">
                            <option value="">-- Select a client to auto-fill pickup details --</option>
                            @foreach(\App\Modules\Admin\Models\Client::where('is_active', true)->orderBy('name')->get() as $client)
                                <option value="{{ $client->id }}" {{ old('client_id', $order->client_id) == $client->id ? 'selected' : '' }}>
                                    {{ $client->name }}{{ $client->company_name ? ' (' . $client->company_name . ')' : '' }} - {{ $client->phone }}
                                </option>
                            @endforeach
                        </select>
                        <p class="mt-1 text-xs text-gray-600">Selecting a client will automatically fill in the pickup information below</p>
                    </div>
                </div>

                <!-- Order Source Information -->
                <div class="md:col-span-2">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Order Source</h3>
                </div>

                <div>
                    <label for="source" class="block text-sm font-medium text-gray-700 mb-2">
                        Order Source <span class="text-red-500">*</span>
                    </label>
                    <select name="source" id="source" required
                            class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                        <option value="">Select source</option>
                        <option value="whatsapp" {{ old('source', $order->source) == 'whatsapp' ? 'selected' : '' }}>WhatsApp</option>
                        <option value="instagram" {{ old('source', $order->source) == 'instagram' ? 'selected' : '' }}>Instagram</option>
                        <option value="web" {{ old('source', $order->source) == 'web' ? 'selected' : '' }}>Website</option>
                        <option value="phone" {{ old('source', $order->source) == 'phone' ? 'selected' : '' }}>Phone Call</option>
                        <option value="walk-in" {{ old('source', $order->source) == 'walk-in' ? 'selected' : '' }}>Walk-in</option>
                        <option value="email" {{ old('source', $order->source) == 'email' ? 'selected' : '' }}>Email</option>
                        <option value="other" {{ old('source', $order->source) == 'other' ? 'selected' : '' }}>Other</option>
                    </select>
                </div>

                <div>
                    <label for="source_contact" class="block text-sm font-medium text-gray-700 mb-2">
                        Source Contact (Phone/Email)
                    </label>
                    <input type="text" name="source_contact" id="source_contact"
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                           value="{{ old('source_contact', $order->source_contact) }}" placeholder="e.g., +234 810 000 0000 or email@example.com">
                </div>

                <div class="md:col-span-2">
                    <label for="source_notes" class="block text-sm font-medium text-gray-700 mb-2">
                        Source Notes
                    </label>
                    <textarea name="source_notes" id="source_notes" rows="3"
                              class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                              placeholder="Any additional notes about the order source">{{ old('source_notes', $order->source_notes) }}</textarea>
                </div>

                <!-- Pickup Information -->
                <div class="md:col-span-2 mt-4">
                    <h3 class="text-lg font-medium text-gray-900 mb-4 pb-2 border-b-2 border-gray-200">Pickup Information</h3>
                </div>

                <div class="md:col-span-2">
                    <label for="pickup_address" class="block text-sm font-medium text-gray-700 mb-2">
                        Pickup Address <span class="text-red-500">*</span>
                    </label>
                    <textarea name="pickup_address" id="pickup_address" rows="3" required
                              class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                              placeholder="Full pickup address">{{ old('pickup_address', $order->pickup_address) }}</textarea>
                </div>

                <div>
                    <label for="sender_name" class="block text-sm font-medium text-gray-700 mb-2">
                        Sender's Name <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="sender_name" id="sender_name" required
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                           value="{{ old('sender_name', $order->sender_name ?? $order->customer_name) }}" placeholder="Full name">
                </div>

                <div>
                    <label for="sender_phone" class="block text-sm font-medium text-gray-700 mb-2">
                        Sender's Phone Number <span class="text-red-500">*</span>
                    </label>
                    <input type="tel" name="sender_phone" id="sender_phone" required
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                           value="{{ old('sender_phone', $order->sender_phone ?? $order->customer_phone) }}" placeholder="+234 810 000 0000">
                </div>

                <div class="md:col-span-2">
                    <label for="sender_email" class="block text-sm font-medium text-gray-700 mb-2">
                        Sender's Email Address
                    </label>
                    <input type="email" name="sender_email" id="sender_email"
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                           value="{{ old('sender_email', $order->sender_email ?? $order->customer_email) }}" placeholder="email@example.com">
                </div>

                <!-- Drop-off Information -->
                <div class="md:col-span-2 mt-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4 pb-2 border-b-2 border-gray-200">Drop-off Information</h3>
                </div>

                <div class="md:col-span-2">
                    <label for="delivery_address" class="block text-sm font-medium text-gray-700 mb-2">
                        Drop-off Address <span class="text-red-500">*</span>
                    </label>
                    <textarea name="delivery_address" id="delivery_address" rows="3" required
                              class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                              placeholder="Full delivery address">{{ old('delivery_address', $order->delivery_address) }}</textarea>
                </div>

                <div>
                    <label for="receiver_name" class="block text-sm font-medium text-gray-700 mb-2">
                        Receiver's Name <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="receiver_name" id="receiver_name" required
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                           value="{{ old('receiver_name', $order->receiver_name) }}" placeholder="Full name">
                </div>

                <div>
                    <label for="receiver_phone" class="block text-sm font-medium text-gray-700 mb-2">
                        Receiver's Phone Number <span class="text-red-500">*</span>
                    </label>
                    <input type="tel" name="receiver_phone" id="receiver_phone" required
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                           value="{{ old('receiver_phone', $order->receiver_phone) }}" placeholder="+234 810 000 0000">
                </div>

                <!-- Package Details -->
                <div class="md:col-span-2 mt-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4 pb-2 border-b-2 border-gray-200">Package Details</h3>
                </div>

                <div class="md:col-span-2">
                    <label for="item_description" class="block text-sm font-medium text-gray-700 mb-2">
                        Item Description <span class="text-red-500">*</span>
                    </label>
                    <textarea name="item_description" id="item_description" rows="3" required
                              class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                              placeholder="Describe the item(s) to be delivered">{{ old('item_description', $order->item_description) }}</textarea>
                </div>

                <!-- Quantity, Size, Weight Row -->
                <div class="md:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label for="quantity" class="block text-sm font-medium text-gray-700 mb-2">
                            Quantity
                        </label>
                        <input type="number" name="quantity" id="quantity" min="1"
                               class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                               value="{{ old('quantity', $order->quantity) }}" placeholder="1">
                    </div>

                    <div>
                        <label for="item_size" class="block text-sm font-medium text-gray-700 mb-2">
                            Size
                        </label>
                        <input type="text" name="item_size" id="item_size"
                               class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                               value="{{ old('item_size', $order->item_size) }}" placeholder="e.g., Small, Medium, Large">
                    </div>

                    <div>
                        <label for="weight" class="block text-sm font-medium text-gray-700 mb-2">
                            Weight (kg)
                        </label>
                        <input type="number" name="weight" id="weight" step="0.01" min="0"
                               class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                               value="{{ old('weight', $order->weight) }}" placeholder="5.00">
                    </div>
                </div>

                @php $deductedStockItems = $order->stockItems->whereNotNull('deducted_at'); @endphp
                @include('Admin::orders.partials.stock-items', [
                    'stockClients' => $stockClients,
                    'existingStockItems' => $order->stockItems->map(fn ($item) => ['client_stock_id' => $item->client_stock_id, 'quantity' => $item->quantity])->all(),
                    'stockLocked' => $deductedStockItems->isNotEmpty(),
                    'lockedStockItems' => $order->stockItems,
                ])

                <div class="md:col-span-2 bg-pink-50 rounded-lg p-4">
                    <h4 class="text-sm font-semibold mb-3 brand-accent-text">Price Calculator</h4>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label for="calc_pickup" class="block text-sm font-medium text-gray-700 mb-2">
                                Pickup Location
                            </label>
                            <input type="text" id="calc_pickup" autocomplete="off"
                                   class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                                   placeholder="">
                        </div>
                        <div>
                            <label for="calc_dropoff" class="block text-sm font-medium text-gray-700 mb-2">
                                Drop-off Location
                            </label>
                            <input type="text" id="calc_dropoff" autocomplete="off"
                                   class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                                   placeholder="">
                        </div>
                        <div>
                            <label for="price" class="block text-sm font-medium text-gray-700 mb-2">
                                Price (₦) <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input type="number" name="price" id="price" step="0.01" min="0" required
                                       class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                                       value="{{ old('price', $order->price) }}" placeholder="Auto-calculated">
                                <button type="button" id="calculate-price-btn" class="absolute right-2 top-1/2 transform -translate-y-1/2 px-3 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors">
                                    Calculate
                                </button>
                            </div>
                            <p class="mt-1 text-xs text-gray-500">Auto-calculated or editable</p>
                        </div>
                    </div>
                </div>

                <!-- Payment -->
                <div class="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6 mt-2">
                    <div>
                        <label for="payment_method" class="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
                        <select name="payment_method" id="payment_method"
                                class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                                onchange="toggleAmountReceived(this.value)">
                            <option value="">-- Select --</option>
                            <option value="cash" {{ old('payment_method', $order->payment_method) == 'cash' ? 'selected' : '' }}>Cash (Pay on Delivery)</option>
                            <option value="credits" {{ old('payment_method', $order->payment_method) == 'credits' ? 'selected' : '' }}>Credits</option>
                            <option value="card" {{ old('payment_method', $order->payment_method) == 'card' ? 'selected' : '' }}>Card</option>
                            <option value="subscription" {{ old('payment_method', $order->payment_method) == 'subscription' ? 'selected' : '' }}>Subscription</option>
                        </select>
                    </div>
                    <div id="amount_received_wrapper" class="{{ old('payment_method', $order->payment_method) == 'cash' ? '' : 'hidden' }}">
                        <label for="amount_received" class="block text-sm font-medium text-gray-700 mb-2">Amount Received (₦)</label>
                        <input type="number" name="amount_received" id="amount_received" step="0.01" min="0"
                               class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                               value="{{ old('amount_received', $order->amount_received) }}"
                               placeholder="Cash collected from customer">
                    </div>
                </div>

                <!-- Remittance -->
                <div id="remittance_wrapper" class="md:col-span-2 {{ old('payment_method', $order->payment_method) == 'cash' && $order->amount_received !== null ? '' : 'hidden' }}">
                    <div class="rounded-lg p-4" style="background-color: #fdf1f1; border: 1px solid #e8a0a4;">
                        <label class="flex items-center gap-3 cursor-pointer">
                            <input type="checkbox" name="mark_remitted" id="mark_remitted" value="1"
                                   class="w-4 h-4 rounded focus:ring-pink-500" style="accent-color: #C1666B;"
                                   {{ old('mark_remitted', $order->remitted_at ? '1' : '') == '1' ? 'checked' : '' }}>
                            <span class="text-sm font-medium text-gray-700">Mark as Remitted</span>
                        </label>
                        @if($order->remitted_at)
                        <p class="mt-1 ml-7 text-xs text-gray-500">Remitted on {{ $order->remitted_at->format('M d, Y h:i A') }}</p>
                        @endif
                    </div>
                </div>

                <!-- Failed Delivery -->
                <div class="md:col-span-2">
                    <div class="rounded-lg p-4 border border-red-200 bg-red-50">
                        <label class="flex items-center gap-3 cursor-pointer">
                            <input type="checkbox" name="is_failed_delivery" id="is_failed_delivery" value="1"
                                   class="w-4 h-4 rounded focus:ring-red-500" style="accent-color: #dc2626;"
                                   {{ old('is_failed_delivery', $order->is_failed_delivery) ? 'checked' : '' }}>
                            <span class="text-sm font-medium text-red-700">Failed Delivery</span>
                        </label>
                    </div>
                </div>

                <!-- Status & Priority Row -->
                <div class="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="status" class="block text-sm font-medium text-gray-700 mb-2">
                            Status <span class="text-red-500">*</span>
                        </label>
                        <select name="status" id="status" required
                                class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent">
                            <option value="pending" {{ old('status', $order->status) == 'pending' ? 'selected' : '' }}>Pending</option>
                            <option value="confirmed" {{ old('status', $order->status) == 'confirmed' ? 'selected' : '' }}>Confirmed</option>
                            <option value="in_transit" {{ old('status', $order->status) == 'in_transit' ? 'selected' : '' }}>In Transit</option>
                            <option value="delivered" {{ old('status', $order->status) == 'delivered' ? 'selected' : '' }}>Delivered</option>
                            <option value="cancelled" {{ old('status', $order->status) == 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                        </select>
                    </div>

                    <div>
                        <label for="priority_level" class="block text-sm font-medium text-gray-700 mb-2">
                            Priority Level <span class="text-red-500">*</span>
                        </label>
                        <select name="priority_level" id="priority_level" required
                                class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent">
                            <option value="normal" {{ old('priority_level', $order->priority_level) == 'normal' ? 'selected' : '' }}>Normal</option>
                            <option value="high" {{ old('priority_level', $order->priority_level) == 'high' ? 'selected' : '' }}>High Priority</option>
                            <option value="urgent" {{ old('priority_level', $order->priority_level) == 'urgent' ? 'selected' : '' }}>Urgent</option>
                        </select>
                        <p class="mt-1 text-xs text-gray-500">High priority and urgent orders will be visited first in the route</p>
                    </div>
                </div>

                <div class="md:col-span-2">
                    <label for="notes" class="block text-sm font-medium text-gray-700 mb-2">
                        Notes
                    </label>
                    <textarea name="notes" id="notes" rows="3"
                              class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                              placeholder="Any additional notes or special instructions">{{ old('notes', $order->notes) }}</textarea>
                </div>

                <!-- Dates -->
                <div>
                    <label for="pickup_date" class="block text-sm font-medium text-gray-700 mb-2">
                        Pickup Date & Time
                    </label>
                    <input type="datetime-local" name="pickup_date" id="pickup_date"
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                           value="{{ old('pickup_date', $order->pickup_date ? $order->pickup_date->format('Y-m-d\TH:i') : '') }}">
                </div>

                <div>
                    <label for="delivery_date" class="block text-sm font-medium text-gray-700 mb-2">
                        Drop-off Date & Time
                    </label>
                    <input type="datetime-local" name="delivery_date" id="delivery_date"
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                           value="{{ old('delivery_date', $order->delivery_date ? $order->delivery_date->format('Y-m-d\TH:i') : '') }}">
                </div>

                <!-- Package Images -->
                <div class="md:col-span-2 mt-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Package Images</h3>
                    <p class="text-sm text-gray-500 mb-4">Upload photos of the package (optional, up to 4 images)</p>
                </div>

                <div>
                    <label for="package_image_1" class="block text-sm font-medium text-gray-700 mb-2">
                        Package Image 1
                    </label>
                    <input type="file" name="package_image_1" id="package_image_1" accept="image/*"
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                    <p class="mt-1 text-xs text-gray-500">JPG, PNG, or GIF (Max 5MB)</p>
                </div>

                <div>
                    <label for="package_image_2" class="block text-sm font-medium text-gray-700 mb-2">
                        Package Image 2
                    </label>
                    <input type="file" name="package_image_2" id="package_image_2" accept="image/*"
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                    <p class="mt-1 text-xs text-gray-500">JPG, PNG, or GIF (Max 5MB)</p>
                </div>

                <div>
                    <label for="package_image_3" class="block text-sm font-medium text-gray-700 mb-2">
                        Package Image 3
                    </label>
                    <input type="file" name="package_image_3" id="package_image_3" accept="image/*"
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                    <p class="mt-1 text-xs text-gray-500">JPG, PNG, or GIF (Max 5MB)</p>
                </div>

                <div>
                    <label for="package_image_4" class="block text-sm font-medium text-gray-700 mb-2">
                        Package Image 4
                    </label>
                    <input type="file" name="package_image_4" id="package_image_4" accept="image/*"
                           class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                    <p class="mt-1 text-xs text-gray-500">JPG, PNG, or GIF (Max 5MB)</p>
                </div>
            </div>

            <!-- Additional Files -->
            <div class="mt-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Additional Files (Optional)</h3>
                <p class="text-sm text-gray-500 mb-4">Upload any other relevant documents (invoices, receipts, etc.)</p>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label for="additional_file_1" class="block text-sm font-medium text-gray-700 mb-2">
                            Additional File 1
                        </label>
                        <input type="file" name="additional_file_1" id="additional_file_1"
                               class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                        <p class="mt-1 text-xs text-gray-500">PDF, DOC, JPG, PNG (Max 5MB)</p>
                        @if($order->additional_file_1)
                            <p class="mt-1 text-xs text-green-600">Current: {{ basename($order->additional_file_1) }}</p>
                        @endif
                    </div>

                    <div>
                        <label for="additional_file_2" class="block text-sm font-medium text-gray-700 mb-2">
                            Additional File 2
                        </label>
                        <input type="file" name="additional_file_2" id="additional_file_2"
                               class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                        <p class="mt-1 text-xs text-gray-500">PDF, DOC, JPG, PNG (Max 5MB)</p>
                        @if($order->additional_file_2)
                            <p class="mt-1 text-xs text-green-600">Current: {{ basename($order->additional_file_2) }}</p>
                        @endif
                    </div>

                    <div>
                        <label for="additional_file_3" class="block text-sm font-medium text-gray-700 mb-2">
                            Additional File 3
                        </label>
                        <input type="file" name="additional_file_3" id="additional_file_3"
                               class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                        <p class="mt-1 text-xs text-gray-500">PDF, DOC, JPG, PNG (Max 5MB)</p>
                        @if($order->additional_file_3)
                            <p class="mt-1 text-xs text-green-600">Current: {{ basename($order->additional_file_3) }}</p>
                        @endif
                    </div>
                </div>
            </div>

            <!-- Form Actions -->
            <div class="mt-8 flex items-center justify-end space-x-4">
                <a href="{{ route('admin.orders.show', $order->id) }}" class="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
                    Cancel
                </a>
                <button type="submit" class="px-6 py-2 text-white rounded-lg brand-accent-bg brand-accent-hover" style="transition: background-color 0.2s ease;">
                    Update Order
                </button>
            </div>
        </form>
    </div>
</div>

<script src="/assets/js/nominatim-autocomplete.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const clientSelect = document.getElementById('client_id');
    const pickupAddressInput = document.getElementById('pickup_address');
    const deliveryAddressInput = document.getElementById('delivery_address');
    const calcPickupInput = document.getElementById('calc_pickup');
    const calcDropoffInput = document.getElementById('calc_dropoff');
    const priceInput = document.getElementById('price');
    const calculateBtn = document.getElementById('calculate-price-btn');

    // Autocomplete on main form fields — also syncs into calculator and auto-calculates price
    nominatimAutocomplete(pickupAddressInput, function(address) {
        calcPickupInput.value = address;
        if (calcPickupInput.value && calcDropoffInput.value) calculatePrice();
    });
    nominatimAutocomplete(deliveryAddressInput, function(address) {
        calcDropoffInput.value = address;
        if (calcPickupInput.value && calcDropoffInput.value) calculatePrice();
    });

    // Autocomplete on standalone calculator fields (for trying a different route)
    nominatimAutocomplete(calcPickupInput, function(address) {
        if (calcPickupInput.value && calcDropoffInput.value) calculatePrice();
    });
    nominatimAutocomplete(calcDropoffInput, function(address) {
        if (calcPickupInput.value && calcDropoffInput.value) calculatePrice();
    });

    // Manual calculate button
    calculateBtn.addEventListener('click', function() {
        if (!calcPickupInput.value || !calcDropoffInput.value) {
            alert('Please enter both pickup and dropoff locations in the calculator fields first');
            return;
        }
        calculatePrice();
    });

    // Calculate price function
    async function calculatePrice() {
        calculateBtn.disabled = true;
        calculateBtn.textContent = 'Calculating...';

        try {
            const response = await fetch('/metter/calculate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({
                    pickup_address: calcPickupInput.value,
                    dropoff_address: calcDropoffInput.value
                })
            });

            const result = await response.json();

            if (result.success && result.data) {
                // Update price only
                priceInput.value = result.data.delivery_fee;
                
                // Flash success
                priceInput.classList.add('bg-green-50', 'border-green-500');
                setTimeout(() => {
                    priceInput.classList.remove('bg-green-50', 'border-green-500');
                }, 2000);
            } else {
                alert(result.message || 'Could not calculate price. Please try again.');
            }
        } catch (error) {
            console.error('Price calculation error:', error);
            alert('Error calculating price. Please try again.');
        } finally {
            calculateBtn.disabled = false;
            calculateBtn.textContent = 'Calculate';
        }
    }

    // Show/hide amount received based on payment method
    window.toggleAmountReceived = function(value) {
        const wrapper = document.getElementById('amount_received_wrapper');
        const remitWrapper = document.getElementById('remittance_wrapper');
        if (value === 'cash') {
            wrapper.classList.remove('hidden');
        } else {
            wrapper.classList.add('hidden');
            document.getElementById('amount_received').value = '';
            remitWrapper.classList.add('hidden');
            document.getElementById('mark_remitted').checked = false;
        }
    };

    // Show remittance checkbox when amount_received is filled
    document.getElementById('amount_received').addEventListener('input', function() {
        const remitWrapper = document.getElementById('remittance_wrapper');
        if (this.value && parseFloat(this.value) > 0) {
            remitWrapper.classList.remove('hidden');
        } else {
            remitWrapper.classList.add('hidden');
            document.getElementById('mark_remitted').checked = false;
        }
    });

    // Client auto-fill
    if (clientSelect) {
        clientSelect.addEventListener('change', function() {
            const clientId = this.value;
            
            if (!clientId) {
                return;
            }
            
            fetch(`/admin/clients/${clientId}/data`)
                .then(response => response.json())
                .then(data => {
                    const fields = {
                        'sender_name': data.name,
                        'sender_phone': data.phone,
                        'sender_email': data.email,
                        'pickup_address': data.pickup_address
                    };
                    
                    Object.keys(fields).forEach(fieldId => {
                        const field = document.getElementById(fieldId);
                        if (field && fields[fieldId]) {
                            field.value = fields[fieldId];
                            field.classList.add('bg-green-50', 'border-green-300');
                            setTimeout(() => {
                                field.classList.remove('bg-green-50', 'border-green-300');
                            }, 1500);
                        }
                    });
                })
                .catch(error => {
                    console.error('Error fetching client data:', error);
                });
        });
    }
});
</script>
@endsection
